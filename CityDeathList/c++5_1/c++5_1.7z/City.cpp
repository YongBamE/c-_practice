#include "City.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

using namespace std;
City::City() {}
City::City(const char* getname) {
	
	
}
char* City::getCityName() {
	return cityName;
};
char* City::getDistrictName() {
	return districtName;
};

void City::setCityName(const char* name) {
	cityName = new char[strlen(name) + 1];
	strcpy(cityName, name);
}

void City::setDistrictName(const char* name){
	districtName = new char[strlen(name) + 1];
	strcpy(districtName, name);

}