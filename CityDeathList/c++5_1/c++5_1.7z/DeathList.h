#pragma once
#include"City.h"
class DeathList
{
private :
	City** city;
	string search;
public:
	DeathList();
	void Dataset();
	void SearchCity();
	string getSearch();

};

